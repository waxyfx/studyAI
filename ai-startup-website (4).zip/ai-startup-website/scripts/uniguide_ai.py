"""
UniGuide AI - Comprehensive University Selection & Admission Planning System
A modular Python application for AI-powered university recommendations and admission planning.
"""

import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
import math


# ============================================================================
# DATA MODELS
# ============================================================================

@dataclass
class StudentProfile:
    """Student profile containing academic and financial information"""
    name: str
    country: str
    gpa: float
    ielts_score: float
    sat_score: Optional[int] = None
    budget_usd: float = 0
    specialties: List[str] = None
    work_experience_years: int = 0
    is_international: bool = True

    def __post_init__(self):
        if self.specialties is None:
            self.specialties = []


@dataclass
class University:
    """University data model"""
    name: str
    country: str
    ranking: int
    avg_gpa: float
    avg_ielts: float
    tuition_per_year_usd: float
    specialties: List[str]
    acceptance_rate: float
    application_fee_usd: float = 50
    scholarship_availability: float = 0.3  # 30% scholarship availability


@dataclass
class AdmissionChances:
    """Admission probability assessment"""
    university_name: str
    overall_chance_percent: float
    gpa_match: float
    ielts_match: float
    specialty_match: float
    ranking_fit: str
    recommendation: str


# ============================================================================
# UNIVERSITY DATABASE
# ============================================================================

UNIVERSITIES_DB = [
    University("Harvard University", "USA", 1, 4.0, 7.5, 55000, ["CS", "Business", "Medicine"], 0.03, 85),
    University("Stanford University", "USA", 3, 3.96, 7.5, 60000, ["CS", "Engineering", "Business"], 0.04, 90),
    University("MIT", "USA", 2, 4.0, 7.5, 62000, ["CS", "Engineering", "Physics"], 0.03, 75),
    University("Cambridge University", "UK", 4, 3.9, 7.0, 35000, ["CS", "Engineering", "Medicine"], 0.04, 65),
    University("Oxford University", "UK", 5, 3.85, 7.0, 33000, ["Business", "Law", "Medicine"], 0.05, 70),
    University("ETH Zurich", "Switzerland", 6, 3.8, 6.5, 1500, ["Engineering", "Physics", "CS"], 0.10, 50),
    University("University of Toronto", "Canada", 25, 3.7, 6.5, 15000, ["Engineering", "Business", "CS"], 0.25, 40),
    University("NUS", "Singapore", 11, 3.8, 6.5, 20000, ["CS", "Engineering", "Business"], 0.20, 45),
    University("University of Melbourne", "Australia", 37, 3.7, 6.5, 25000, ["Engineering", "CS", "Business"], 0.30, 50),
    University("TU Delft", "Netherlands", 53, 3.6, 6.5, 8000, ["Engineering", "CS"], 0.35, 30),
]


# ============================================================================
# CORE UniversityAI CLASS
# ============================================================================

class UniversityAI:
    """Main class for AI-powered university selection and admission planning"""

    def __init__(self, student: StudentProfile):
        self.student = student
        self.universities = UNIVERSITIES_DB
        self.results = {}

    def match_universities(self, limit: int = 10) -> List[Dict]:
        """
        Match student with suitable universities based on profile
        Returns ranked list of universities
        """
        matches = []

        for uni in self.universities:
            score = self._calculate_match_score(uni)
            affordability = self._check_affordability(uni)
            specialty_match = self._check_specialty_match(uni)

            if score > 0:
                matches.append({
                    "university": uni.name,
                    "country": uni.country,
                    "ranking": uni.ranking,
                    "match_score": round(score, 2),
                    "affordability": affordability,
                    "specialty_match": specialty_match,
                    "tuition_per_year": uni.tuition_per_year_usd,
                    "annual_cost_estimate": self._estimate_annual_cost(uni)
                })

        matches.sort(key=lambda x: x["match_score"], reverse=True)
        self.results["matched_universities"] = matches[:limit]
        return matches[:limit]

    def assess_admission_chances(self) -> List[Dict]:
        """
        Assess chances of admission for matched universities
        Returns detailed assessment for each university
        """
        chances = []
        matched_unis = [m["university"] for m in self.results.get("matched_universities", [])]

        for uni in self.universities:
            if uni.name in matched_unis:
                assessment = self._calculate_admission_chances(uni)
                chances.append(asdict(assessment))

        chances.sort(key=lambda x: x["overall_chance_percent"], reverse=True)
        self.results["admission_chances"] = chances
        return chances

    def _calculate_match_score(self, uni: University) -> float:
        """Calculate overall match score"""
        gpa_score = (self.student.gpa / uni.avg_gpa) * 40
        ielts_score = (self.student.ielts_score / uni.avg_ielts) * 30
        specialty_score = 20 if self._check_specialty_match(uni) else 0
        budget_score = 10 if self._check_affordability(uni) else 5

        return min(100, gpa_score + ielts_score + specialty_score + budget_score)

    def _calculate_admission_chances(self, uni: University) -> AdmissionChances:
        """Calculate detailed admission chances"""
        gpa_match = (self.student.gpa / uni.avg_gpa) * 100
        ielts_match = (self.student.ielts_score / uni.avg_ielts) * 100
        specialty_match = 100 if self._check_specialty_match(uni) else 50

        overall = (gpa_match * 0.4 + ielts_match * 0.3 + specialty_match * 0.3)
        overall = min(95, max(5, overall))

        if overall >= 70:
            ranking_fit = "High"
            recommendation = "Strong candidate"
        elif overall >= 50:
            ranking_fit = "Medium"
            recommendation = "Competitive candidate"
        else:
            ranking_fit = "Low"
            recommendation = "Reach school"

        return AdmissionChances(
            university_name=uni.name,
            overall_chance_percent=round(overall, 1),
            gpa_match=round(gpa_match, 1),
            ielts_match=round(ielts_match, 1),
            specialty_match=specialty_match,
            ranking_fit=ranking_fit,
            recommendation=recommendation
        )

    def _check_affordability(self, uni: University) -> bool:
        """Check if university is affordable"""
        total_cost = self._calculate_total_cost(uni)
        return total_cost <= self.student.budget_usd * 2

    def _check_specialty_match(self, uni: University) -> bool:
        """Check if specialties match"""
        if not self.student.specialties:
            return True
        return any(s in uni.specialties for s in self.student.specialties)

    def _estimate_annual_cost(self, uni: University) -> float:
        """Estimate total annual cost"""
        living_cost = self._estimate_living_cost(uni.country)
        return uni.tuition_per_year_usd + living_cost

    def _estimate_living_cost(self, country: str) -> float:
        """Estimate living costs by country"""
        costs = {
            "USA": 15000,
            "UK": 12000,
            "Canada": 10000,
            "Australia": 13000,
            "Switzerland": 18000,
            "Netherlands": 11000,
            "Singapore": 12000
        }
        return costs.get(country, 10000)

    def _calculate_total_cost(self, uni: University) -> float:
        """Calculate total cost for 2 years"""
        return self._estimate_annual_cost(uni) * 2

    def _calculate_scholarship_score(self) -> float:
        """Calculate scholarship eligibility score"""
        score = self.student.gpa * 25
        if self.student.work_experience_years > 0:
            score += 10
        return min(100, score)

    def generate_comprehensive_report(self) -> Dict:
        """Generate complete analysis report"""
        self.match_universities()
        self.assess_admission_chances()

        return {
            "student_profile": asdict(self.student),
            "matched_universities": self.results.get("matched_universities", []),
            "admission_chances": self.results.get("admission_chances", []),
            "timestamp": datetime.now().isoformat()
        }


# ============================================================================
# CLI INTERFACE
# ============================================================================

def main():
    """Main CLI interface"""
    print("=" * 70)
    print("UniGuide AI - University Selection Assistant")
    print("=" * 70)

    # Demo student profile
    student = StudentProfile(
        name="Demo Student",
        country="International",
        gpa=3.8,
        ielts_score=7.0,
        sat_score=1400,
        budget_usd=80000,
        specialties=["CS", "Engineering"],
        work_experience_years=2
    )

    # Run analysis
    ai = UniversityAI(student)
    report = ai.generate_comprehensive_report()

    # Print results
    print("\n📊 MATCHED UNIVERSITIES:")
    print("-" * 70)
    for uni in report["matched_universities"][:5]:
        print(f"\n🎓 {uni['university']}")
        print(f"   📍 {uni['country']}")
        print(f"   📈 Ranking: #{uni['ranking']}")
        print(f"   ✅ Match Score: {uni['match_score']}%")
        print(f"   💰 Annual Cost: ${uni['annual_cost_estimate']:,.0f}")

    print("\n" + "=" * 70)
    print(f"✅ Analysis complete! Found {len(report['matched_universities'])} matches.")
    print("=" * 70)


if __name__ == "__main__":
    main()
