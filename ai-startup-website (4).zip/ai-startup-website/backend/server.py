# backend/server.py
import os
import sys
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

# Добавляем путь к папке, где лежит scripts/uniguide_ai.py
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS_PATH = os.path.join(ROOT, "scripts")
if SCRIPTS_PATH not in sys.path:
    sys.path.append(SCRIPTS_PATH)

# Импортируем твой класс UniversityAI из scripts/uniguide_ai.py
try:
    from uniguide_ai import StudentProfile, UniversityAI
except Exception as e:
    # Если импорт не удался, выбросим понятную ошибку при старте
    print("Error importing uniguide_ai:", e)
    raise

app = FastAPI(title="UniGuide AI Backend")

# Разрешаем CORS с локального фронтенда и любых хостов (для теста).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # на продакшне ставь конкретный домен
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic модель входных данных (подстрой под поля формы на ai.html)
class StudentInput(BaseModel):
    name: Optional[str] = "Anonymous"
    country: Optional[str] = "any"
    gpa: float
    ielts_score: float
    sat_score: Optional[int] = None
    budget_usd: float = 0
    specialties: Optional[List[str]] = []
    work_experience_years: Optional[int] = 0
    is_international: Optional[bool] = True

class ChatMessage(BaseModel):
    message: str
    student_profile: Optional[StudentInput] = None
    chat_history: Optional[List[dict]] = []

@app.post("/api/analyze")
def analyze(input: StudentInput):
    try:
        # Создаём StudentProfile аналогично тому, как он определён в uniguide_ai.py
        student = StudentProfile(
            name = input.name,
            country = input.country,
            gpa = input.gpa,
            ielts_score = input.ielts_score,
            sat_score = input.sat_score,
            budget_usd = input.budget_usd,
            specialties = input.specialties,
            work_experience_years = input.work_experience_years,
            is_international = input.is_international
        )

        ai = UniversityAI(student)
        report = ai.generate_comprehensive_report()
        return {"ok": True, "report": report}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/chat")
def chat(input: ChatMessage):
    try:
        # Check if message contains keywords that trigger full analysis
        trigger_words = ["анализ", "подбор", "университет", "analyze", "recommend", "universities"]
        should_analyze = any(word in input.message.lower() for word in trigger_words)
        
        # If profile provided and trigger words detected, do full analysis
        if input.student_profile and should_analyze:
            student = StudentProfile(
                name=input.student_profile.name,
                country=input.student_profile.country,
                gpa=input.student_profile.gpa,
                ielts_score=input.student_profile.ielts_score,
                sat_score=input.student_profile.sat_score,
                budget_usd=input.student_profile.budget_usd,
                specialties=input.student_profile.specialties,
                work_experience_years=input.student_profile.work_experience_years,
                is_international=input.student_profile.is_international
            )
            
            ai = UniversityAI(student)
            report = ai.generate_comprehensive_report()
            
            response_text = f"Я провел полный анализ вашего профиля. Вот результаты:\n\n"
            response_text += f"Ваши шансы на поступление: {report.get('overall_chances', 'N/A')}%\n\n"
            
            if report.get('high_chance_universities'):
                response_text += f"Университеты с высоким шансом поступления: {len(report['high_chance_universities'])} университетов\n"
            
            return {
                "ok": True,
                "response": response_text,
                "full_analysis": report
            }
        
        # Otherwise, provide conversational response
        response_text = generate_chat_response(input.message, input.student_profile, input.chat_history)
        
        return {
            "ok": True,
            "response": response_text,
            "full_analysis": None
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def generate_chat_response(message: str, profile: Optional[StudentInput], history: List[dict]) -> str:
    """
    Generate contextual chat responses based on message and profile
    """
    message_lower = message.lower()
    
    # Greetings
    if any(word in message_lower for word in ["привет", "здравствуй", "hello", "hi"]):
        return "Привет! Я ваш ИИ-ассистент по поступлению в университеты. Чем могу помочь?"
    
    # University selection questions
    if any(word in message_lower for word in ["университет", "вуз", "university"]):
        if profile:
            return f"Отлично! Я вижу, вы хотите поступить в {profile.country}. Для более точных рекомендаций, расскажите о ваших приоритетах: престиж, стоимость, или конкретная программа?"
        return "Я помогу вам подобрать университет! Сначала мне нужно знать ваши данные: GPA, результаты экзаменов, бюджет и специальность."
    
    # Budget and scholarship questions
    if any(word in message_lower for word in ["бюджет", "стипендия", "грант", "scholarship", "budget"]):
        if profile and profile.budget_usd == 0:
            return "Отлично! Вы ищете полное финансирование. Я рекомендую обратить внимание на программы с грантами и стипендиями. В каких странах вы рассматриваете обучение?"
        return "Понимаю, финансирование важно. Расскажите о вашем бюджете, и я подберу университеты с подходящими стипендиями и грантами."
    
    # Chances analysis
    if any(word in message_lower for word in ["шанс", "вероятность", "chances", "probability"]):
        if profile:
            return f"С GPA {profile.gpa} и IELTS {profile.ielts_score}, у вас хорошие шансы! Хотите, я проведу полный анализ по конкретным университетам?"
        return "Чтобы оценить ваши шансы, мне нужны данные о вашем профиле: GPA, результаты экзаменов, достижения."
    
    # Essay and documents help
    if any(word in message_lower for word in ["эссе", "письмо", "essay", "motivation"]):
        return "Мотивационное письмо - важная часть заявки! Я помогу структурировать его. Расскажите о вашем опыте и целях обучения."
    
    # Visa support
    if any(word in message_lower for word in ["виза", "visa", "документы", "documents"]):
        return "Оформление визы требует подготовки. Для начала определите страну обучения, и я предоставлю список необходимых документов."
    
    # Default response
    return "Спасибо за ваш вопрос! Я могу помочь с:\n- Подбором университетов\n- Анализом шансов поступления\n- Планом подготовки\n- Поиском стипендий\n- Помощью с документами\n\nО чем хотите узнать подробнее?"

@app.get("/")
def root():
    return {"status": "UniGuide AI backend running"}
