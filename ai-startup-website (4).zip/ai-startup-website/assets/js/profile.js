// Declare Auth and Database variables before using them
let Auth
let Database

document.addEventListener("DOMContentLoaded", () => {
  // Check if Auth and Database exist in global scope, initialize them if needed
  if (typeof window.Auth !== "undefined") {
    Auth = window.Auth
  } else {
    console.error("Auth module not loaded")
    return
  }

  if (typeof window.Database !== "undefined") {
    Database = window.Database
  } else {
    console.error("Database module not loaded")
    return
  }

  Auth.init()
  const user = Auth.getCurrentUser()

  if (!user) {
    window.location.href = "auth/login.html"
    return
  }

  document.getElementById("userName").textContent = user.name
  document.getElementById("userEmail").textContent = user.email

  const history = Database.getHistory(user.email)
  const discussions = Database.getDiscussions(user.email)
  const events = Database.getCalendarEvents(user.email)

  document.getElementById("historyCount").textContent = history.length
  document.getElementById("discussionCount").textContent = discussions.length
  document.getElementById("eventCount").textContent = events.length
})
