// UniversityAI Engine - JavaScript Implementation
// This is a JavaScript port of the Python AI engine for real-time analysis

class UniversityAI {
  constructor() {
    this.universities = [
      {
        name: "Harvard University",
        country: "USA",
        ranking: 1,
        avg_gpa: 4.0,
        avg_ielts: 7.5,
        tuition_per_year_usd: 55000,
        specialties: ["CS", "Business", "Medicine"],
        acceptance_rate: 0.03,
        application_fee_usd: 85,
        scholarship_availability: 0.3,
      },
      {
        name: "Stanford University",
        country: "USA",
        ranking: 3,
        avg_gpa: 3.96,
        avg_ielts: 7.5,
        tuition_per_year_usd: 60000,
        specialties: ["CS", "Engineering", "Business"],
        acceptance_rate: 0.04,
        application_fee_usd: 90,
        scholarship_availability: 0.3,
      },
      {
        name: "MIT",
        country: "USA",
        ranking: 2,
        avg_gpa: 4.0,
        avg_ielts: 7.5,
        tuition_per_year_usd: 62000,
        specialties: ["CS", "Engineering", "Physics"],
        acceptance_rate: 0.03,
        application_fee_usd: 75,
        scholarship_availability: 0.3,
      },
      {
        name: "Cambridge University",
        country: "UK",
        ranking: 4,
        avg_gpa: 3.9,
        avg_ielts: 7.0,
        tuition_per_year_usd: 35000,
        specialties: ["CS", "Engineering", "Medicine"],
        acceptance_rate: 0.04,
        application_fee_usd: 65,
        scholarship_availability: 0.25,
      },
      {
        name: "Oxford University",
        country: "UK",
        ranking: 5,
        avg_gpa: 3.85,
        avg_ielts: 7.0,
        tuition_per_year_usd: 33000,
        specialties: ["Business", "Law", "Medicine"],
        acceptance_rate: 0.05,
        application_fee_usd: 70,
        scholarship_availability: 0.25,
      },
      {
        name: "ETH Zurich",
        country: "Switzerland",
        ranking: 6,
        avg_gpa: 3.8,
        avg_ielts: 6.5,
        tuition_per_year_usd: 1500,
        specialties: ["Engineering", "Physics", "CS"],
        acceptance_rate: 0.1,
        application_fee_usd: 50,
        scholarship_availability: 0.2,
      },
      {
        name: "University of Toronto",
        country: "Canada",
        ranking: 25,
        avg_gpa: 3.7,
        avg_ielts: 6.5,
        tuition_per_year_usd: 15000,
        specialties: ["Engineering", "Business", "CS"],
        acceptance_rate: 0.25,
        application_fee_usd: 40,
        scholarship_availability: 0.35,
      },
      {
        name: "NUS (National University of Singapore)",
        country: "Singapore",
        ranking: 11,
        avg_gpa: 3.8,
        avg_ielts: 6.5,
        tuition_per_year_usd: 20000,
        specialties: ["CS", "Engineering", "Business"],
        acceptance_rate: 0.2,
        application_fee_usd: 45,
        scholarship_availability: 0.3,
      },
      {
        name: "University of Melbourne",
        country: "Australia",
        ranking: 37,
        avg_gpa: 3.7,
        avg_ielts: 6.5,
        tuition_per_year_usd: 25000,
        specialties: ["Engineering", "CS", "Business"],
        acceptance_rate: 0.3,
        application_fee_usd: 50,
        scholarship_availability: 0.3,
      },
      {
        name: "TU Delft",
        country: "Netherlands",
        ranking: 53,
        avg_gpa: 3.6,
        avg_ielts: 6.5,
        tuition_per_year_usd: 8000,
        specialties: ["Engineering", "CS"],
        acceptance_rate: 0.35,
        application_fee_usd: 30,
        scholarship_availability: 0.25,
      },
    ]
  }

  // Map English level to IELTS score
  mapEnglishLevelToIELTS(englishLevel) {
    const mapping = {
      beginner: 3.5,
      elementary: 4.5,
      intermediate: 5.5,
      "upper-intermediate": 6.5,
      advanced: 7.5,
      mastery: 8.5,
    }
    return mapping[englishLevel] || 6.0
  }

  // Map budget range to numeric value
  mapBudgetRange(budgetRange) {
    const mapping = {
      "0-30000": 30000,
      "30000-60000": 60000,
      "60000-100000": 100000,
      "100000+": 150000,
    }
    return mapping[budgetRange] || 50000
  }

  // Estimate living cost by country
  estimateLivingCost(country) {
    const costs = {
      USA: 15000,
      UK: 12000,
      Canada: 10000,
      Australia: 13000,
      Switzerland: 18000,
      Netherlands: 11000,
      Singapore: 12000,
    }
    return costs[country] || 10000
  }

  // Calculate annual cost
  calculateAnnualCost(uni) {
    return uni.tuition_per_year_usd + this.estimateLivingCost(uni.country)
  }

  // Calculate total cost (2 years)
  calculateTotalCost(uni) {
    return this.calculateAnnualCost(uni) * 2
  }

  // Check specialty match
  checkSpecialtyMatch(uni, studentSpecialties) {
    if (!studentSpecialties || studentSpecialties.length === 0) return true

    return studentSpecialties.some((specialty) =>
      uni.specialties.some((uniSpecialty) => uniSpecialty.toLowerCase().includes(specialty.toLowerCase())),
    )
  }

  // Check affordability
  checkAffordability(uni, budget) {
    const totalCost = this.calculateTotalCost(uni)
    return totalCost <= budget * 2
  }

  // Calculate match score
  calculateMatchScore(uni, student) {
    const gpaScore = (student.gpa / uni.avg_gpa) * 40
    const ieltsScore = (student.ielts / uni.avg_ielts) * 30
    const specialtyScore = this.checkSpecialtyMatch(uni, student.specialties) ? 20 : 0
    const budgetScore = this.checkAffordability(uni, student.budget) ? 10 : 5

    return Math.min(100, gpaScore + ieltsScore + specialtyScore + budgetScore)
  }

  // Calculate admission chances
  calculateAdmissionChances(uni, student) {
    const gpaMatch = (student.gpa / uni.avg_gpa) * 100
    const ieltsMatch = (student.ielts / uni.avg_ielts) * 100
    const specialtyMatch = this.checkSpecialtyMatch(uni, student.specialties) ? 100 : 50

    let overall = gpaMatch * 0.4 + ieltsMatch * 0.3 + specialtyMatch * 0.3
    overall = Math.min(95, Math.max(5, overall))

    let rankingFit, recommendation
    if (overall >= 70) {
      rankingFit = "High"
      recommendation = "Высокий шанс поступления"
    } else if (overall >= 50) {
      rankingFit = "Medium"
      recommendation = "Средний шанс поступления"
    } else {
      rankingFit = "Low"
      recommendation = "Низкий шанс, но попробовать стоит"
    }

    return {
      university_name: uni.name,
      overall_chance_percent: Math.round(overall * 10) / 10,
      gpa_match: Math.round(gpaMatch * 10) / 10,
      ielts_match: Math.round(ieltsMatch * 10) / 10,
      specialty_match: specialtyMatch,
      ranking_fit: rankingFit,
      recommendation: recommendation,
    }
  }

  // Main analysis function
  analyze(formData) {
    console.log("[v0] Starting AI analysis with form data:", formData)

    // Parse student data
    const student = {
      gpa: Number.parseFloat(formData.gpa) || 3.5,
      ielts: this.mapEnglishLevelToIELTS(formData.english),
      budget: this.mapBudgetRange(formData.budget),
      specialties: formData.major ? [formData.major] : [],
      country: formData.country,
    }

    console.log("[v0] Parsed student profile:", student)

    // Match universities
    const matches = []
    for (const uni of this.universities) {
      const matchScore = this.calculateMatchScore(uni, student)
      const admissionChances = this.calculateAdmissionChances(uni, student)

      if (matchScore > 0) {
        matches.push({
          university: uni.name,
          country: uni.country,
          ranking: uni.ranking,
          match_score: Math.round(matchScore * 10) / 10,
          affordability: this.checkAffordability(uni, student.budget),
          specialty_match: this.checkSpecialtyMatch(uni, student.specialties),
          tuition_per_year: uni.tuition_per_year_usd,
          annual_cost_estimate: this.calculateAnnualCost(uni),
          admission_chances: admissionChances.overall_chance_percent,
          recommendation: admissionChances.recommendation,
        })
      }
    }

    // Sort by match score
    matches.sort((a, b) => b.match_score - a.match_score)

    console.log("[v0] Found matches:", matches.length)

    // Categorize universities
    const highChance = matches.filter((m) => m.admission_chances >= 70)
    const mediumChance = matches.filter((m) => m.admission_chances >= 50 && m.admission_chances < 70)
    const lowChance = matches.filter((m) => m.admission_chances < 50)

    // Calculate overall chances
    const avgChance = matches.reduce((sum, m) => sum + m.admission_chances, 0) / (matches.length || 1)

    // Generate plan
    const plan = this.generateAdmissionPlan(formData.deadline, student)

    // Generate recommendations
    const recommendations = this.generateRecommendations(student, matches)

    return {
      overall_chances: Math.round(avgChance),
      high_chance: highChance.slice(0, 5).map((m) => ({
        name: m.university,
        country: m.country,
        ranking: m.ranking,
        tuition: `$${m.tuition_per_year.toLocaleString()}`,
        chance: `${Math.round(m.admission_chances)}%`,
      })),
      medium_chance: mediumChance.slice(0, 5).map((m) => ({
        name: m.university,
        country: m.country,
        ranking: m.ranking,
        tuition: `$${m.tuition_per_year.toLocaleString()}`,
        chance: `${Math.round(m.admission_chances)}%`,
      })),
      low_chance: lowChance.slice(0, 5).map((m) => ({
        name: m.university,
        country: m.country,
        ranking: m.ranking,
        tuition: `$${m.tuition_per_year.toLocaleString()}`,
        chance: `${Math.round(m.admission_chances)}%`,
      })),
      plan: plan,
      recommendations: recommendations,
    }
  }

  // Generate admission plan based on deadline
  generateAdmissionPlan(deadline, student) {
    const plans = {
      urgent: [
        "🚨 Срочно: начните подготовку документов прямо сейчас",
        "📝 Подготовьте мотивационное письмо (1-2 недели)",
        "📧 Запросите рекомендательные письма у преподавателей",
        `📚 Улучшите английский до ${student.ielts} IELTS (или эквивалент)`,
        "🎯 Подайте заявки в ближайшие 2-4 недели",
        "💼 Подготовьтесь к возможным интервью",
      ],
      soon: [
        "📋 Составьте список университетов (4-6 недель до дедлайна)",
        "📝 Напишите мотивационное письмо (2-3 недели)",
        "📧 Соберите рекомендательные письма от преподавателей",
        `📚 Подготовьтесь к IELTS/TOEFL (целевой балл: ${student.ielts})`,
        "💰 Изучите возможности финансирования и стипендий",
        "🎯 Подайте документы за 6-8 недель до дедлайна",
        "💼 Практикуйте интервью и презентацию себя",
      ],
      normal: [
        "🎯 Исследуйте университеты тщательно (2-3 месяца)",
        "📚 Пройдите языковой тест IELTS/TOEFL",
        "📝 Подготовьте сильное мотивационное письмо",
        "📧 Попросите 2-3 рекомендательных письма",
        "💰 Составьте финансовый план и изучите стипендии",
        "📋 Соберите все необходимые документы",
        "🎯 Подайте заявки за 3-4 месяца до дедлайна",
        "💼 Подготовьтесь к интервью и тестам",
      ],
      flexible: [
        "🔍 Тщательно изучите все варианты университетов",
        `📚 Повысьте языковой уровень до ${student.ielts}+ IELTS`,
        "🎯 Участвуйте в волонтёрстве и проектах",
        "📝 Создайте выдающееся мотивационное письмо",
        "📧 Установите связи с преподавателями для рекомендаций",
        "💰 Максимизируйте шансы на стипендии",
        "📋 Подготовьте безупречное портфолио",
        "🎯 Подавайте заявки в оптимальное время",
      ],
    }

    return plans[deadline] || plans.normal
  }

  // Generate personalized recommendations
  generateRecommendations(student, matches) {
    const recommendations = []

    // GPA recommendations
    if (student.gpa >= 3.8) {
      recommendations.push("✅ Отличный GPA! У вас сильная академическая база")
    } else if (student.gpa >= 3.5) {
      recommendations.push("👍 Хороший GPA. Усильте профиль волонтёрством и проектами")
    } else {
      recommendations.push("📈 Компенсируйте GPA сильным мотивационным письмом и достижениями")
    }

    // IELTS recommendations
    if (student.ielts >= 7.0) {
      recommendations.push("🌟 Отличный уровень английского языка")
    } else if (student.ielts >= 6.5) {
      recommendations.push("📚 Хороший английский. Можете улучшить для топ-университетов")
    } else {
      recommendations.push("⚠️ Рекомендуем интенсивную подготовку к языковому тесту")
    }

    // Budget recommendations
    const affordableCount = matches.filter((m) => m.affordability).length
    if (affordableCount > 5) {
      recommendations.push("💰 У вас достаточно вариантов в рамках бюджета")
    } else if (affordableCount > 0) {
      recommendations.push("💡 Изучите стипендии для расширения возможностей")
    } else {
      recommendations.push("💸 Рассмотрите стипендии и гранты - это критически важно")
    }

    // Specialty recommendations
    if (student.specialties.length > 0) {
      recommendations.push(`🎓 Нашли университеты с сильными программами по ${student.specialties[0]}`)
    }

    // General advice
    recommendations.push("📅 Начните подготовку минимум за 6 месяцев до дедлайна")
    recommendations.push("🔗 Налаживайте связи с выпускниками выбранных университетов")

    return recommendations
  }
}

// Make it globally available
window.UniversityAI = UniversityAI
