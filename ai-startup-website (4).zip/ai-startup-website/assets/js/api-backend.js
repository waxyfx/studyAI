// API Backend Connection Module
// Handles all communication with FastAPI backend

class APIBackend {
  constructor() {
    // Default to localhost for development
    // Change this to your deployed backend URL for production
    this.baseURL = "http://127.0.0.1:8000"

    // Check if backend is available
    this.isAvailable = false
    this.checkAvailability()
  }

  async checkAvailability() {
    try {
      const response = await fetch(`${this.baseURL}/`)
      if (response.ok) {
        this.isAvailable = true
        console.log("[v0] Backend is available")
      }
    } catch (error) {
      console.log("[v0] Backend is not available, using demo mode")
      this.isAvailable = false
    }
  }

  // Convert form data to API format
  convertFormDataToProfile(formData) {
    // Extract exams data
    const exams = formData.exams || []

    // Find IELTS score
    let ieltsScore = 0
    const ieltsExam = exams.find((e) => e.type === "IELTS")
    if (ieltsExam) {
      ieltsScore = Number.parseFloat(ieltsExam.score) || 0
    }

    // Find SAT score
    let satScore = null
    const satExam = exams.find((e) => e.type === "SAT")
    if (satExam) {
      satScore = Number.parseInt(satExam.score) || null
    }

    // Parse budget
    let budgetUsd = 0
    if (formData.budget === "grant" || formData.budget === "grant-stipend") {
      budgetUsd = 0 // Free/full scholarship
    } else if (formData.budget === "100000+") {
      budgetUsd = 100000
    } else {
      // Extract min value from range (e.g., "30000-60000" -> 30000)
      const match = formData.budget.match(/(\d+)/)
      if (match) {
        budgetUsd = Number.parseInt(match[1])
      }
    }

    return {
      name: formData.name || "Anonymous",
      country: formData.country || "any",
      gpa: Number.parseFloat(formData.gpa) || 3.0,
      ielts_score: ieltsScore,
      sat_score: satScore,
      budget_usd: budgetUsd,
      specialties: formData.major ? [formData.major] : [],
      work_experience_years: 0,
      is_international: true,
    }
  }

  // POST /api/analyze - Get full university recommendations
  async analyzeProfile(formData) {
    try {
      const profile = this.convertFormDataToProfile(formData)

      console.log("[v0] Sending profile to backend:", profile)

      const response = await fetch(`${this.baseURL}/api/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(profile),
      })

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] Received analysis from backend:", data)

      return {
        success: true,
        report: data.report,
      }
    } catch (error) {
      console.error("[v0] Error analyzing profile:", error)
      return {
        success: false,
        error: error.message,
      }
    }
  }

  // POST /api/chat - Chat with AI
  async sendChatMessage(message, formData = null) {
    try {
      let profile = null
      if (formData) {
        profile = this.convertFormDataToProfile(formData)
      }

      console.log("[v0] Sending chat message:", message)

      const response = await fetch(`${this.baseURL}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: message,
          student_profile: profile,
        }),
      })

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] Received chat response:", data)

      return {
        success: true,
        response: data.response,
        full_analysis: data.full_analysis || null,
      }
    } catch (error) {
      console.error("[v0] Error sending chat message:", error)
      return {
        success: false,
        error: error.message,
      }
    }
  }
}

// Create global instance
window.APIBackend = new APIBackend()
