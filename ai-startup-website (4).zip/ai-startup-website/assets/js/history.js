// Declare Auth and Database variables before using them
let Auth, Database

document.addEventListener("DOMContentLoaded", () => {
  // Check if Auth and Database are loaded
  if (typeof window.Auth === "undefined" || typeof window.Database === "undefined") {
    console.error("Required modules not loaded")
    return
  }

  // Assign Auth and Database from window object
  Auth = window.Auth
  Database = window.Database

  Auth.init()
  const user = Auth.getCurrentUser()

  if (!user) {
    window.location.href = "auth/login.html"
    return
  }

  const history = Database.getHistory(user.email)
  const historyList = document.getElementById("historyList")

  if (history.length === 0) {
    historyList.innerHTML = '<p class="empty-message">История пуста</p>'
    return
  }

  historyList.innerHTML = history
    .reverse()
    .map(
      (item) => `
    <div class="history-item">
      <div class="history-item-header">
        <div class="history-item-title">${item.country} - ${item.major}</div>
        <div class="history-item-date">${new Date(item.timestamp).toLocaleDateString("ru-RU")}</div>
      </div>
      <div class="history-item-details">
        <p>GPA: ${item.gpa} | Бюджет: ${item.budget} | Английский: ${item.english}</p>
      </div>
      <div class="history-item-actions">
        <a href="ai.html?loadHistory=${item.id}">Повторить поиск</a>
        <a onclick="deleteHistoryItem('${user.email}', ${item.id})" style="background: var(--danger); cursor: pointer;">Удалить</a>
      </div>
    </div>
  `,
    )
    .join("")
})

function deleteHistoryItem(userId, historyId) {
  if (confirm("Удалить этот элемент?")) {
    if (typeof Database === "undefined") {
      console.error("Database module not loaded")
      return
    }
    Database.deleteHistoryItem(userId, historyId)
    location.reload()
  }
}
