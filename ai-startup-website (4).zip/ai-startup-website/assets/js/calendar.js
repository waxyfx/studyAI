const currentMonth = new Date()
let currentUser = null

const Auth = require("./Auth") // Assuming Auth is a module
const Database = require("./Database") // Assuming Database is a module

document.addEventListener("DOMContentLoaded", () => {
  if (typeof Auth === "undefined" || typeof Database === "undefined") {
    console.error("Required modules not loaded")
    return
  }

  Auth.init()
  currentUser = Auth.getCurrentUser()

  if (!currentUser) {
    window.location.href = "auth/login.html"
    return
  }

  renderCalendar()
  renderEvents()

  const eventForm = document.getElementById("eventForm")
  if (eventForm) {
    eventForm.addEventListener("submit", addEvent)
  }
})

function renderCalendar() {
  const calendar = document.getElementById("calendar")
  const firstDay = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1)
  const lastDay = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0)
  const events = Database.getCalendarEvents(currentUser.email)

  let html = `
    <div class="calendar-nav" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <button onclick="prevMonth()" class="btn btn-secondary">← Пред</button>
      <h3>${currentMonth.toLocaleDateString("ru-RU", { month: "long", year: "numeric" })}</h3>
      <button onclick="nextMonth()" class="btn btn-secondary">След →</button>
    </div>
    <div class="calendar-grid">
  `

  const dayNames = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]
  dayNames.forEach((day) => {
    html += `<div style="font-weight: bold; text-align: center; padding: 10px;">${day}</div>`
  })

  for (let i = 0; i < firstDay.getDay() - 1; i++) {
    html += "<div></div>"
  }

  for (let day = 1; day <= lastDay.getDate(); day++) {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    const hasEvent = events.some((e) => new Date(e.date).toDateString() === date.toDateString())
    html += `<div class="calendar-day ${hasEvent ? "has-event" : ""}">${day}</div>`
  }

  html += "</div>"
  calendar.innerHTML = html
}

function renderEvents() {
  const eventsList = document.getElementById("eventsList")
  const events = Database.getCalendarEvents(currentUser.email).sort((a, b) => new Date(a.date) - new Date(b.date))

  if (events.length === 0) {
    eventsList.innerHTML = '<p class="empty">Нет событий</p>'
    return
  }

  eventsList.innerHTML = events
    .map(
      (event) => `
    <div class="event-item">
      <div class="event-info">
        <h3>${event.title}</h3>
        <div class="event-date">${new Date(event.date).toLocaleDateString("ru-RU")}</div>
        <div class="event-description">${event.description}</div>
      </div>
      <div class="event-actions">
        <button onclick="deleteEvent(${event.id})">Удалить</button>
      </div>
    </div>
  `,
    )
    .join("")
}

function addEvent(e) {
  e.preventDefault()

  const event = {
    title: document.getElementById("eventTitle").value,
    date: document.getElementById("eventDate").value,
    description: document.getElementById("eventDescription").value,
  }

  Database.saveCalendarEvent(currentUser.email, event)
  closeAddEventModal()
  renderCalendar()
  renderEvents()
}

function deleteEvent(eventId) {
  if (confirm("Удалить событие?")) {
    Database.deleteCalendarEvent(currentUser.email, eventId)
    renderCalendar()
    renderEvents()
  }
}

function prevMonth() {
  currentMonth.setMonth(currentMonth.getMonth() - 1)
  renderCalendar()
}

function nextMonth() {
  currentMonth.setMonth(currentMonth.getMonth() + 1)
  renderCalendar()
}

function openAddEventModal() {
  document.getElementById("eventModal").classList.add("active")
}

function closeAddEventModal() {
  document.getElementById("eventModal").classList.remove("active")
  document.getElementById("eventForm").reset()
}
