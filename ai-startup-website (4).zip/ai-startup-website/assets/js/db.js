// Database management system

const Database = {
  // Save search/query results to user's history
  saveToHistory(userId, queryData) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    users[userId].history = users[userId].history || []
    users[userId].history.push({
      id: Date.now(),
      ...queryData,
      timestamp: new Date().toISOString(),
    })

    Storage.save("users", users)
    return true
  },

  // Get user's history
  getHistory(userId) {
    const users = Storage.get("users") || {}
    return users[userId]?.history || []
  },

  getSearchHistory(userId) {
    return this.getHistory(userId)
  },

  // Save calendar event
  saveCalendarEvent(userId, event) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    users[userId].calendar = users[userId].calendar || []
    users[userId].calendar.push({
      id: Date.now(),
      ...event,
      createdAt: new Date().toISOString(),
    })

    Storage.save("users", users)
    return true
  },

  // Get calendar events
  getCalendarEvents(userId) {
    const users = Storage.get("users") || {}
    return users[userId]?.calendar || []
  },

  // Save discussion/chat with AI
  saveDiscussion(userId, discussion) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    users[userId].discussions = users[userId].discussions || []

    if (!discussion.id) {
      discussion.id = Date.now().toString()
    }

    discussion.id = String(discussion.id)

    users[userId].discussions.push({
      ...discussion,
      createdAt: discussion.createdAt || new Date().toISOString(),
    })

    Storage.save("users", users)
    return true
  },

  // Get discussions
  getDiscussions(userId) {
    const users = Storage.get("users") || {}
    return users[userId]?.discussions || []
  },

  // Delete history item
  deleteHistoryItem(userId, historyId) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    users[userId].history = users[userId].history.filter((h) => h.id !== historyId)
    Storage.save("users", users)
    return true
  },

  // Delete calendar event
  deleteCalendarEvent(userId, eventId) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    users[userId].calendar = users[userId].calendar.filter((e) => e.id !== eventId)
    Storage.save("users", users)
    return true
  },

  // Delete discussion
  deleteDiscussion(userId, discussionId) {
    const users = Storage.get("users") || {}
    if (!users[userId]) return false

    discussionId = String(discussionId)
    users[userId].discussions = users[userId].discussions.filter((d) => String(d.id) !== discussionId)
    Storage.save("users", users)
    return true
  },
}

if (typeof window !== "undefined") {
  window.Database = Database
}
