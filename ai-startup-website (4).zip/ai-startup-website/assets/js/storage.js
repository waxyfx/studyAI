// LocalStorage utility functions

const Storage = {
  save(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data))
      return true
    } catch (e) {
      console.error("Storage error:", e)
      return false
    }
  },

  get(key) {
    try {
      const data = localStorage.getItem(key)
      return data ? JSON.parse(data) : null
    } catch (e) {
      console.error("Storage error:", e)
      return null
    }
  },

  remove(key) {
    try {
      localStorage.removeItem(key)
      return true
    } catch (e) {
      console.error("Storage error:", e)
      return false
    }
  },

  clear() {
    try {
      localStorage.clear()
      return true
    } catch (e) {
      console.error("Storage error:", e)
      return false
    }
  },
}
