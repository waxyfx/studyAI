let currentDiscussionId = null
let currentUser = null
let currentFunction = null
let backend = null

const AI_FUNCTIONS = {
  "university-selection": { name: "Подбор университетов", icon: "🎯" },
  planning: { name: "План поступления", icon: "📋" },
  "chances-analysis": { name: "Анализ шансов", icon: "📊" },
  "budget-scholarships": { name: "Бюджет и стипендии", icon: "💰" },
  "program-comparison": { name: "Сравнение программ", icon: "⚖️" },
  "visa-support": { name: "Помощь с визой", icon: "🛂" },
  "essay-help": { name: "Помощь с эссе", icon: "✍️" },
  "career-advice": { name: "Карьерные советы", icon: "🚀" },
}

document.addEventListener("DOMContentLoaded", () => {
  if (typeof window.Auth === "undefined" || typeof window.Database === "undefined") {
    console.log("[v0] Required modules not loaded, waiting...")
    setTimeout(() => {
      initializeChat()
    }, 500)
    return
  }

  initializeChat()
})

function initializeChat() {
  backend = window.APIBackend

  if (typeof window.Auth !== "undefined") {
    window.Auth.init()
    currentUser = window.Auth.getCurrentUser()
  }

  const Storage = window.Storage || {
    get: (key) => {
      try {
        return JSON.parse(localStorage.getItem(key))
      } catch {
        return null
      }
    },
    save: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value))
      } catch {}
    },
  }

  // Check for temporary discussion
  const tempDiscussion = Storage.get("tempDiscussion")
  const activeDiscussionId = Storage.get("activeDiscussionId")

  if (tempDiscussion && activeDiscussionId && activeDiscussionId.startsWith("temp_")) {
    console.log("[v0] Loading temporary discussion:", activeDiscussionId)
    loadTemporaryDiscussion(tempDiscussion)
    return
  }

  // Regular flow - require login for saved discussions
  if (!currentUser) {
    console.log("[v0] No user logged in, redirecting to login")
    window.location.href = "login.html"
    return
  }

  loadDiscussions()

  // Check if there's an active discussion to load from ai.html
  if (activeDiscussionId) {
    console.log("[v0] Loading active discussion:", activeDiscussionId)
    // Clear the stored ID
    Storage.save("activeDiscussionId", null)
    // Load the discussion
    selectDiscussion(activeDiscussionId)
  } else {
    // Show function selector
    document.getElementById("functionSelector").style.display = "block"
  }
}

function loadTemporaryDiscussion(discussion) {
  currentDiscussionId = discussion.id
  currentFunction = discussion.functionType || "university-selection"

  // Hide sidebar for temp users
  document.querySelector(".chat-sidebar").style.display = "none"
  document.querySelector(".chat-main-area").style.width = "100%"

  // Show banner for temp users
  const chatMainArea = document.querySelector(".chat-main-area")
  const banner = document.createElement("div")
  banner.className = "temp-user-banner"
  banner.style.cssText =
    "background: #fff3cd; border: 1px solid #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 8px; text-align: center;"
  banner.innerHTML = `
    <p style="margin: 0 0 10px 0; font-weight: 500;">Вы используете временный чат</p>
    <p style="margin: 0 0 10px 0; font-size: 14px;">Зарегистрируйтесь, чтобы сохранить историю</p>
    <button class="btn btn-primary btn-small" onclick="window.location.href='register.html'" style="margin-right: 10px;">Регистрация</button>
    <button class="btn btn-secondary btn-small" onclick="window.location.href='login.html'">Вход</button>
  `
  chatMainArea.insertBefore(banner, chatMainArea.firstChild)

  document.getElementById("currentFunctionTitle").textContent = discussion.title
  document.getElementById("functionSelector").style.display = "none"
  document.getElementById("chatArea").style.display = "flex"

  renderMessages(discussion.messages || [])

  setTimeout(() => {
    const messagesList = document.getElementById("messagesList")
    if (messagesList) {
      messagesList.scrollTop = messagesList.scrollHeight
    }
  }, 100)
}

function loadDiscussions() {
  const discussions = window.Database.getDiscussions(currentUser.email)
  const discussionsList = document.getElementById("discussionsList")

  if (discussions.length === 0) {
    discussionsList.innerHTML = '<p class="empty">Нет обсуждений</p>'
    return
  }

  discussionsList.innerHTML = discussions
    .reverse()
    .map(
      (disc) => `
      <div class="discussion-item ${currentDiscussionId === disc.id ? "active" : ""}" onclick="selectDiscussion('${disc.id}')">
        <div class="discussion-item-header">
          <span class="function-icon-small">${AI_FUNCTIONS[disc.functionType]?.icon || "💬"}</span>
          <strong>${disc.title}</strong>
        </div>
        <small>${new Date(disc.createdAt).toLocaleDateString("ru-RU")}</small>
      </div>
    `,
    )
    .join("")
}

function selectDiscussion(discussionId) {
  currentDiscussionId = discussionId
  const discussions = window.Database.getDiscussions(currentUser.email)
  const discussion = discussions.find((d) => d.id === discussionId)

  if (!discussion) {
    console.error("[v0] Discussion not found:", discussionId)
    return
  }

  currentFunction = discussion.functionType || "university-selection"
  document.getElementById("currentFunctionTitle").textContent = discussion.title
  document.getElementById("functionSelector").style.display = "none"
  document.getElementById("chatArea").style.display = "flex"

  renderMessages(discussion.messages || [])
  loadDiscussions()

  setTimeout(() => {
    const messagesList = document.getElementById("messagesList")
    if (messagesList) {
      messagesList.scrollTop = messagesList.scrollHeight
    }
  }, 100)
}

function renderMessages(messages = []) {
  const messagesList = document.getElementById("messagesList")

  if (!messages || messages.length === 0) {
    messagesList.innerHTML =
      '<p style="text-align: center; color: var(--text-light); padding: 20px;">Начните беседу</p>'
    return
  }

  messagesList.innerHTML = messages
    .map(
      (msg) => `
      <div class="message ${msg.sender}">
        <div class="message-content">${escapeHtml(msg.text)}</div>
        <div class="message-time">${new Date(msg.timestamp).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</div>
      </div>
    `,
    )
    .join("")

  messagesList.scrollTop = messagesList.scrollHeight
}

async function sendMessage(event) {
  event.preventDefault()

  const messageText = document.getElementById("messageInput").value.trim()
  if (!messageText) return

  const Storage = window.Storage || {
    get: (key) => {
      try {
        return JSON.parse(localStorage.getItem(key))
      } catch {
        return null
      }
    },
    save: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value))
      } catch {}
    },
  }

  let discussion

  if (currentDiscussionId && currentDiscussionId.startsWith("temp_")) {
    // Temporary discussion
    discussion = Storage.get("tempDiscussion")
    if (!discussion) {
      console.error("[v0] Temp discussion not found")
      return
    }
  } else {
    // Saved discussion
    const discussions = window.Database.getDiscussions(currentUser.email)
    discussion = discussions.find((d) => d.id === currentDiscussionId)
    if (!discussion) {
      console.error("[v0] Discussion not found")
      return
    }
  }

  if (!discussion.messages) discussion.messages = []

  // Add user message
  discussion.messages.push({
    sender: "user",
    text: messageText,
    timestamp: new Date().toISOString(),
    functionType: currentFunction,
  })

  // Clear input immediately for better UX
  document.getElementById("messageInput").value = ""

  // Show user message immediately
  renderMessages(discussion.messages)

  // Add typing indicator
  const messagesList = document.getElementById("messagesList")
  const typingIndicator = document.createElement("div")
  typingIndicator.className = "message ai typing"
  typingIndicator.innerHTML = '<div class="message-content">ИИ печатает...</div>'
  messagesList.appendChild(typingIndicator)
  messagesList.scrollTop = messagesList.scrollHeight

  try {
    let aiResponse = ""

    // Try to use backend API if available
    if (backend && backend.isAvailable) {
      console.log("[v0] Sending message to backend")

      const formData = discussion.formData || Storage.get("aiFormData")

      const result = await backend.sendChatMessage(messageText, formData)

      if (result.success) {
        aiResponse = result.response

        // If full analysis provided, save it
        if (result.full_analysis) {
          Storage.save("aiResults", result.full_analysis)
        }
      } else {
        // Fallback to local generation
        console.log("[v0] Backend failed, using local generation")
        aiResponse = generateAIResponse(messageText, currentFunction, discussion)
      }
    } else {
      // Use local AI response generation
      console.log("[v0] Using local AI response generation")
      aiResponse = generateAIResponse(messageText, currentFunction, discussion)
    }

    // Remove typing indicator
    typingIndicator.remove()

    // Add AI response
    discussion.messages.push({
      sender: "ai",
      text: aiResponse,
      timestamp: new Date().toISOString(),
      functionType: currentFunction,
    })

    // Save discussion
    if (currentDiscussionId && currentDiscussionId.startsWith("temp_")) {
      // Save temp discussion
      Storage.save("tempDiscussion", discussion)
    } else {
      // Save to database
      window.Database.deleteDiscussion(currentUser.email, currentDiscussionId)
      window.Database.saveDiscussion(currentUser.email, discussion)
    }

    renderMessages(discussion.messages)

    setTimeout(() => {
      messagesList.scrollTop = messagesList.scrollHeight
    }, 100)
  } catch (error) {
    console.error("[v0] Error sending message:", error)

    // Remove typing indicator
    typingIndicator.remove()

    // Add error message
    discussion.messages.push({
      sender: "ai",
      text: "Извините, произошла ошибка. Попробуйте еще раз.",
      timestamp: new Date().toISOString(),
      functionType: currentFunction,
    })

    renderMessages(discussion.messages)
  }
}

function generateAIResponse(messageText, functionType, discussion) {
  const lowerText = messageText.toLowerCase()

  // Check if user is asking about results
  if (discussion?.results) {
    if (lowerText.includes("университет") || lowerText.includes("рекоменд")) {
      const totalUniversities =
        (discussion.results.high_chance?.length || 0) +
        (discussion.results.medium_chance?.length || 0) +
        (discussion.results.low_chance?.length || 0)
      return `Я подобрал для вас ${totalUniversities} университетов: ${discussion.results.high_chance?.length || 0} с высоким шансом, ${discussion.results.medium_chance?.length || 0} со средним и ${discussion.results.low_chance?.length || 0} престижных университетов. Хотите узнать больше о каком-то конкретном университете?`
    }

    if (lowerText.includes("шанс") || lowerText.includes("вероятн")) {
      return `Ваши общие шансы на поступление составляют ${discussion.results.overall_chances || 65}%. Это хороший показатель! Хотите, расскажу как его улучшить?`
    }

    if (lowerText.includes("план") || lowerText.includes("подготов")) {
      const planSteps = discussion.results.plan || []
      if (planSteps.length > 0) {
        return `Вот ваш персональный план:\n\n${planSteps.slice(0, 3).join("\n")}\n\nХотите обсудить какой-то из этих шагов подробнее?`
      }
    }
  }

  // Generic responses based on function type
  const responses = {
    "university-selection": [
      "Расскажите подробнее о ваших предпочтениях по университетам. Что для вас важнее всего?",
      "Я могу помочь вам выбрать университеты исходя из ваших целей и возможностей. Что вас интересует?",
      "Давайте обсудим ваши приоритеты: престиж университета, стоимость обучения или шансы на поступление?",
    ],
    planning: [
      "Хороший план — половина успеха. Давайте разберем, какие шаги нужно предпринять первыми.",
      "Я помогу составить детальный план подготовки. С чего бы вы хотели начать?",
      "Расскажите, сколько времени у вас есть до подачи документов?",
    ],
    "chances-analysis": [
      "Для точной оценки шансов мне нужно знать больше о ваших достижениях. Расскажите подробнее.",
      "Ваши шансы зависят от многих факторов. Давайте разберем каждый из них.",
      "Я проанализирую ваш профиль и дам рекомендации по улучшению шансов на поступление.",
    ],
  }

  const functionResponses = responses[functionType] || responses["university-selection"]
  return functionResponses[Math.floor(Math.random() * functionResponses.length)]
}

function startDiscussion(functionType) {
  currentFunction = functionType
  const functionName = AI_FUNCTIONS[functionType].name

  const newDiscussion = {
    id: Date.now().toString(),
    title: functionName,
    functionType: functionType,
    messages: [],
    createdAt: new Date().toISOString(),
  }

  window.Database.saveDiscussion(currentUser.email, newDiscussion)
  currentDiscussionId = newDiscussion.id

  loadDiscussions()
  selectDiscussion(currentDiscussionId)
}

function newDiscussionMenu() {
  currentDiscussionId = null
  document.getElementById("chatArea").style.display = "none"
  document.getElementById("functionSelector").style.display = "block"
}

function backToFunctionSelector() {
  document.getElementById("chatArea").style.display = "none"
  document.getElementById("functionSelector").style.display = "block"
}

function escapeHtml(text) {
  const div = document.createElement("div")
  div.textContent = text
  return div.innerHTML
}
