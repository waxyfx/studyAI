// Active nav link
document.addEventListener("DOMContentLoaded", () => {
  const navLinks = document.querySelectorAll(".nav-links a")
  const currentPage = window.location.pathname.split("/").pop() || "index.html"

  navLinks.forEach((link) => {
    const href = link.getAttribute("href")
    if (href === currentPage || (currentPage === "" && href === "index.html")) {
      link.classList.add("active")
    } else {
      link.classList.remove("active")
    }
  })

  updateAuthUI()
})

function updateAuthUI() {
  // Check if Auth is loaded
  const Auth = window.Auth // Declare the Auth variable here
  if (typeof Auth === "undefined") return

  Auth.init()
  const currentUser = Auth.getCurrentUser()
  const navContainer = document.querySelector(".navbar-container")

  if (!navContainer) return

  // Remove existing auth nav if present
  const existingAuthNav = navContainer.querySelector(".nav-auth")
  if (existingAuthNav) {
    existingAuthNav.remove()
  }

  const authNav = document.createElement("div")
  authNav.className = "nav-auth"

  if (currentUser) {
    // User is logged in
    authNav.innerHTML = `
      <div class="user-menu">
        <button class="user-button" onclick="toggleUserMenu()">👤 ${currentUser.name}</button>
        <div class="dropdown-menu" id="userDropdown">
          <a href="profile.html">📊 Профиль</a>
          <a href="history.html">📋 История</a>
          <a href="calendar.html">📅 Календарь</a>
          <a href="chat.html">💬 Чаты</a>
          <a href="#" onclick="logoutUser(event)">🚪 Выход</a>
        </div>
      </div>
    `
  } else {
    // User not logged in
    authNav.innerHTML = `
      <a href="auth/login.html" class="btn btn-primary">Вход</a>
      <a href="auth/register.html" class="btn btn-secondary">Регистрация</a>
    `
  }

  navContainer.appendChild(authNav)
}

function toggleUserMenu() {
  const dropdown = document.getElementById("userDropdown")
  if (dropdown) {
    dropdown.classList.toggle("active")
  }
}

function logoutUser(event) {
  event.preventDefault()
  const Auth = window.Auth // Declare the Auth variable here
  if (typeof Auth === "undefined") return

  Auth.logout()
  window.location.href = "index.html"
}

// Close dropdown when clicking outside
document.addEventListener("click", (e) => {
  const dropdown = document.getElementById("userDropdown")
  const userMenu = document.querySelector(".user-menu")
  if (dropdown && userMenu && !userMenu.contains(e.target)) {
    dropdown.classList.remove("active")
  }
})
