// Navigation Authentication Handler
// Manages the display of auth buttons vs user menu in navigation

const Auth = {
  getCurrentUser: () => {
    // Mock implementation for demonstration purposes
    return { name: "John Doe" }
  },
  logout: () => {
    // Mock implementation for demonstration purposes
    console.log("User logged out")
  },
}

document.addEventListener("DOMContentLoaded", () => {
  updateNavAuth()
})

function updateNavAuth() {
  const navAuth = document.getElementById("navAuth")
  const userMenu = document.getElementById("userMenu")

  if (!navAuth || !userMenu) return

  const currentUser = Auth.getCurrentUser()

  if (currentUser) {
    // User is logged in - show user menu
    navAuth.style.display = "none"
    userMenu.style.display = "block"

    const userName = document.getElementById("userName")
    if (userName) {
      userName.textContent = currentUser.name
    }

    // Setup dropdown toggle
    const userButton = document.getElementById("userButton")
    const dropdownMenu = document.getElementById("dropdownMenu")

    if (userButton && dropdownMenu) {
      userButton.addEventListener("click", (e) => {
        e.stopPropagation()
        dropdownMenu.classList.toggle("active")
      })

      // Close dropdown when clicking outside
      document.addEventListener("click", () => {
        dropdownMenu.classList.remove("active")
      })
    }

    // Setup logout button
    const logoutBtn = document.getElementById("logoutBtn")
    if (logoutBtn) {
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault()
        Auth.logout()
        window.location.href = "index.html"
      })
    }
  } else {
    // User is not logged in - show auth buttons
    navAuth.style.display = "flex"
    userMenu.style.display = "none"
  }
}
