// Authentication system with localStorage database

const Auth = {
  // Initialize database if doesn't exist
  init() {
    if (!Storage.get("users")) {
      Storage.save("users", {})
    }
    if (!Storage.get("currentUser")) {
      Storage.save("currentUser", null)
    }
  },

  // Register new user
  register(name, email, password) {
    this.init()
    const users = Storage.get("users") || {}

    if (users[email]) {
      return { success: false, error: "Email already registered" }
    }

    users[email] = {
      name,
      email,
      password: this.hashPassword(password),
      createdAt: new Date().toISOString(),
      history: [],
      calendar: [],
      discussions: [],
    }

    Storage.save("users", users)
    return { success: true, message: "Registration successful" }
  },

  // Login user
  login(email, password) {
    this.init()
    const users = Storage.get("users") || {}

    if (!users[email]) {
      return { success: false, error: "User not found" }
    }

    if (users[email].password !== this.hashPassword(password)) {
      return { success: false, error: "Incorrect password" }
    }

    const user = users[email]
    Storage.save("currentUser", {
      name: user.name,
      email: user.email,
    })

    return { success: true, user }
  },

  // Logout user
  logout() {
    Storage.save("currentUser", null)
  },

  // Get current user
  getCurrentUser() {
    return Storage.get("currentUser")
  },

  hashPassword(password) {
    try {
      return btoa(password)
    } catch (e) {
      // Fallback for older browsers
      return password
        .split("")
        .map((c) => c.charCodeAt(0).toString(16))
        .join("")
    }
  },

  // Check if user is authenticated
  isAuthenticated() {
    return !!this.getCurrentUser()
  },
}

if (typeof window !== "undefined") {
  window.Auth = Auth
}

// Handle login form
if (document.getElementById("loginForm")) {
  Auth.init()
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault()
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    const result = Auth.login(email, password)
    if (result.success) {
      window.location.href = "ai.html"
    } else {
      alert(result.error)
    }
  })
}

// Handle register form
if (document.getElementById("registerForm")) {
  Auth.init()
  document.getElementById("registerForm").addEventListener("submit", (e) => {
    e.preventDefault()
    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const confirmPassword = document.getElementById("confirmPassword").value

    if (password !== confirmPassword) {
      alert("Passwords don't match")
      return
    }

    const result = Auth.register(name, email, password)
    if (result.success) {
      alert("Registration successful! Please login.")
      window.location.href = "login.html"
    } else {
      alert(result.error)
    }
  })
}
