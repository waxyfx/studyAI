// Chat History Page Handler

document.addEventListener("DOMContentLoaded", () => {
  loadChatHistory()
})

function loadChatHistory() {
  const Auth = window.Auth
  const Database = window.Database

  const currentUser = Auth.getCurrentUser()

  if (!currentUser) {
    window.location.href = "auth/login.html"
    return
  }

  const discussions = Database.getDiscussions(currentUser.email)
  const historyContent = document.getElementById("historyContent")

  if (discussions.length === 0) {
    historyContent.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💬</div>
        <h3>Нет истории чатов</h3>
        <p>Начните диалог с ИИ, чтобы увидеть историю здесь</p>
        <a href="ai.html" class="btn btn-primary">Начать с ИИ</a>
      </div>
    `
    return
  }

  historyContent.innerHTML = discussions
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((discussion) => {
      const date = new Date(discussion.createdAt).toLocaleDateString("ru-RU", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })

      const messageCount = discussion.messages?.length || 0

      return `
        <div class="chat-card" onclick="openChat(${discussion.id})">
          <div class="chat-card-header">
            <h3 class="chat-title">${discussion.title}</h3>
            <button class="btn-delete" onclick="deleteChat(event, ${discussion.id})">🗑️</button>
          </div>
          <div class="chat-meta">
            <span class="chat-date">📅 ${date}</span>
            <span class="chat-messages">💬 ${messageCount} сообщений</span>
          </div>
          ${
            discussion.formData
              ? `
            <div class="chat-preview">
              <span class="preview-tag">🎓 ${discussion.formData.major || "Специальность"}</span>
              <span class="preview-tag">🌍 ${discussion.formData.country || "Страна"}</span>
              <span class="preview-tag">📊 GPA: ${discussion.formData.gpa || "N/A"}</span>
            </div>
          `
              : ""
          }
        </div>
      `
    })
    .join("")
}

function openChat(discussionId) {
  window.location.href = `chat.html?id=${discussionId}`
}

function deleteChat(event, discussionId) {
  event.stopPropagation()

  if (!confirm("Вы уверены, что хотите удалить этот чат?")) {
    return
  }

  const Auth = window.Auth
  const Database = window.Database
  const currentUser = Auth.getCurrentUser()

  if (currentUser) {
    Database.deleteDiscussion(currentUser.email, discussionId)
    loadChatHistory()
  }
}
