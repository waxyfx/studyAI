// Universities Catalog

const universitiesDatabase = [
  {
    name: "Harvard University",
    country: "usa",
    ranking: 4,
    tuition: "$60,000",
    major: "computer-science",
    emoji: "🎓",
  },
  {
    name: "MIT",
    country: "usa",
    ranking: 2,
    tuition: "$65,000",
    major: "computer-science",
    emoji: "🔬",
  },
  {
    name: "Stanford University",
    country: "usa",
    ranking: 5,
    tuition: "$62,000",
    major: "computer-science",
    emoji: "🌳",
  },
  {
    name: "University of Oxford",
    country: "uk",
    ranking: 3,
    tuition: "$55,000",
    major: "business",
    emoji: "📚",
  },
  {
    name: "Cambridge University",
    country: "uk",
    ranking: 2,
    tuition: "$58,000",
    major: "engineering",
    emoji: "🏛️",
  },
  {
    name: "University of Toronto",
    country: "canada",
    ranking: 26,
    tuition: "$35,000",
    major: "engineering",
    emoji: "🍁",
  },
  {
    name: "University of Melbourne",
    country: "australia",
    ranking: 37,
    tuition: "$42,000",
    major: "medicine",
    emoji: "🦘",
  },
  {
    name: "University of Amsterdam",
    country: "netherlands",
    ranking: 50,
    tuition: "$22,000",
    major: "business",
    emoji: "🇳🇱",
  },
  {
    name: "ETH Zurich",
    country: "germany",
    ranking: 11,
    tuition: "$18,000",
    major: "engineering",
    emoji: "⛏️",
  },
  {
    name: "TU Munich",
    country: "germany",
    ranking: 42,
    tuition: "$15,000",
    major: "engineering",
    emoji: "🏭",
  },
]

document.addEventListener("DOMContentLoaded", () => {
  renderUniversities(universitiesDatabase)
})

function renderUniversities(universities) {
  const grid = document.getElementById("universitiesGrid")
  grid.innerHTML = universities
    .map(
      (uni) => `
        <div class="university-item">
            <div class="university-image">${uni.emoji}</div>
            <div class="university-content">
                <div class="university-name">${uni.name}</div>
                <div class="university-country">🌍 ${getCountryName(uni.country)}</div>
                <div class="university-info">
                    <div class="info-row">
                        <strong>Рейтинг QS:</strong>
                        <span>#${uni.ranking}</span>
                    </div>
                    <div class="info-row">
                        <strong>Стоимость:</strong>
                        <span>${uni.tuition}</span>
                    </div>
                    <div class="info-row">
                        <strong>Специальность:</strong>
                        <span>${getMajorName(uni.major)}</span>
                    </div>
                </div>
                <div class="university-actions">
                    <a href="#" class="btn-learn-more">Подробнее</a>
                    <button class="btn-save" onclick="saveUniversity(this)">💾 Сохранить</button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")
}

function getCountryName(code) {
  const countries = {
    usa: "США",
    uk: "Великобритания",
    canada: "Канада",
    australia: "Австралия",
    netherlands: "Нидерланды",
    germany: "Германия",
  }
  return countries[code] || code
}

function getMajorName(code) {
  const majors = {
    "computer-science": "Computer Science",
    business: "Business",
    engineering: "Engineering",
    medicine: "Medicine",
    arts: "Arts & Humanities",
  }
  return majors[code] || code
}

function applyFilters() {
  const country = document.getElementById("filterCountry").value
  const ranking = document.getElementById("filterRanking").value
  const major = document.getElementById("filterMajor").value
  const tuition = document.getElementById("filterTuition").value

  let filtered = universitiesDatabase

  if (country) {
    filtered = filtered.filter((u) => u.country === country)
  }

  if (major) {
    filtered = filtered.filter((u) => u.major === major)
  }

  if (ranking) {
    const [min, max] = ranking.split("-").map(Number)
    filtered = filtered.filter((u) => {
      if (ranking === "301+") return u.ranking > 300
      return u.ranking >= min && u.ranking <= max
    })
  }

  if (tuition) {
    filtered = filtered.filter((u) => {
      const price = Number.parseInt(u.tuition.replace(/\D/g, ""))
      if (tuition === "0-30000") return price <= 30000
      if (tuition === "30000-60000") return price >= 30000 && price <= 60000
      if (tuition === "60000+") return price >= 60000
    })
  }

  renderUniversities(filtered)
}

function saveUniversity(btn) {
  btn.textContent = "✅ Сохранено"
  setTimeout(() => {
    btn.textContent = "💾 Сохранить"
  }, 2000)
}
