// AI Assistant Form Handler

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("aiForm")
  if (form) {
    form.addEventListener("submit", handleFormSubmit)
    // Load last saved form data if available
    loadSavedFormData()
  }

  addExamInput()
})

let examCounter = 0

function addExamInput() {
  examCounter++
  const container = document.getElementById("examsContainer")

  const examDiv = document.createElement("div")
  examDiv.className = "exam-input-group"
  examDiv.id = `exam-${examCounter}`

  examDiv.innerHTML = `
    <div class="exam-select-row">
      <select name="exam_type_${examCounter}" class="exam-select" onchange="showScoreInput(${examCounter})">
        <option value="">Выберите экзамен</option>
        <option value="IELTS">IELTS (0-9)</option>
        <option value="TOEFL">TOEFL (0-120)</option>
        <option value="SAT">SAT (400-1600)</option>
        <option value="ACT">ACT (1-36)</option>
        <option value="GRE">GRE (260-340)</option>
        <option value="GMAT">GMAT (200-800)</option>
        <option value="A-Level">A-Level (A*-E)</option>
        <option value="IB">IB (0-45)</option>
        <option value="UBT">UBT (0-140)</option>
        <option value="AP">AP (1-5)</option>
        <option value="Duolingo">Duolingo (10-160)</option>
      </select>
      ${examCounter > 1 ? `<button type="button" class="btn-remove-exam" onclick="removeExamInput(${examCounter})">✕</button>` : ""}
    </div>
    <div id="score-input-${examCounter}" class="exam-score-input" style="display: none;">
      <input type="text" name="exam_score_${examCounter}" placeholder="Введите балл" class="score-input">
    </div>
  `

  container.appendChild(examDiv)
}

function removeExamInput(id) {
  const examDiv = document.getElementById(`exam-${id}`)
  if (examDiv) {
    examDiv.remove()
  }
}

function showScoreInput(id) {
  const scoreDiv = document.getElementById(`score-input-${id}`)
  const select = document.querySelector(`select[name="exam_type_${id}"]`)

  if (select.value) {
    scoreDiv.style.display = "block"
  } else {
    scoreDiv.style.display = "none"
  }
}

async function handleFormSubmit(e) {
  e.preventDefault()

  const formData = new FormData(document.getElementById("aiForm"))
  const userData = Object.fromEntries(formData)

  const exams = []
  for (let i = 1; i <= examCounter; i++) {
    const examType = formData.get(`exam_type_${i}`)
    const examScore = formData.get(`exam_score_${i}`)
    if (examType && examScore) {
      exams.push({ type: examType, score: examScore })
    }
  }
  userData.exams = exams

  // Save to localStorage
  Storage.save("aiFormData", userData)

  // Show loader and results section
  const resultsSection = document.getElementById("resultsSection")
  const loader = document.getElementById("loader")
  const resultsContent = document.getElementById("resultsContent")

  resultsSection.style.display = "block"
  loader.style.display = "flex"
  resultsContent.style.display = "none"

  // Scroll to results
  resultsSection.scrollIntoView({ behavior: "smooth" })

  try {
    const backend = window.APIBackend

    if (backend.isAvailable) {
      console.log("[v0] Using real backend API")
      const result = await backend.analyzeProfile(userData)

      if (result.success) {
        // Convert backend report to display format
        const results = convertBackendReportToResults(result.report, userData)

        // Hide loader, show results
        loader.style.display = "none"
        resultsContent.style.display = "block"

        displayResults(results)
        return
      }
    }

    console.log("[v0] Backend not available, using local AI engine")

    // Fallback to local AI engine
    const aiEngine = new window.UniversityAI()

    // Simulate processing time for better UX
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const results = aiEngine.analyze(userData)

    // Hide loader, show results
    loader.style.display = "none"
    resultsContent.style.display = "block"

    // Display results
    displayResults(results)
  } catch (error) {
    console.error("Error in AI analysis:", error)
    loader.style.display = "none"
    resultsContent.style.display = "block"

    // Show demo results as fallback
    displayDemoResults(userData)
  }
}

function convertBackendReportToResults(report, userData) {
  // Extract data from backend report structure
  // Assuming report has universities, plan, recommendations, etc.

  const results = {
    overall_chances: report.overall_chances || 65,
    high_chance: report.high_chance_universities || [],
    medium_chance: report.medium_chance_universities || [],
    low_chance: report.reach_universities || [],
    plan: report.personalized_plan || [],
    recommendations: report.recommendations || [],
  }

  return results
}

function displayResults(results) {
  // Overall chances
  const chances = results.overall_chances || 65
  const chancesBar = document.getElementById("chancesBar")
  const chancesText = document.getElementById("chancesText")

  chancesBar.style.width = chances + "%"
  chancesBar.style.backgroundColor = chances >= 70 ? "#10b981" : chances >= 50 ? "#f59e0b" : "#ef4444"
  chancesText.textContent = `Ваши общие шансы: ${chances}%`

  // Universities by category
  displayUniversitiesByCategory("highChanceUniversities", results.high_chance || [])
  displayUniversitiesByCategory("mediumChanceUniversities", results.medium_chance || [])
  displayUniversitiesByCategory("lowChanceUniversities", results.low_chance || [])

  // Plan
  const planContent = document.getElementById("planContent")
  planContent.innerHTML = (results.plan || [])
    .map(
      (step, index) => `
        <div class="plan-step">
            <div class="plan-step-number">${index + 1}</div>
            <div class="plan-step-content">${step}</div>
        </div>
    `,
    )
    .join("")

  // Recommendations
  const recommendationsContent = document.getElementById("recommendationsContent")
  recommendationsContent.innerHTML = (results.recommendations || [])
    .map(
      (rec) => `
        <div class="recommendation-item">
            <span class="recommendation-icon">💡</span>
            <span class="recommendation-text">${rec}</span>
        </div>
    `,
    )
    .join("")

  // Save results
  Storage.save("aiResults", results)
}

function displayDemoResults(userData) {
  // Demo mode when backend is not available
  const gpa = Number.parseFloat(userData.gpa) || 3.5
  const chances = Math.min(95, Math.max(30, (gpa / 4.0) * 100))

  const demoResults = {
    overall_chances: Math.round(chances),
    high_chance: [
      { name: "University of Example", country: "USA", ranking: 45, tuition: "$45,000", chance: "75%" },
      { name: "Tech Institute", country: "Canada", ranking: 52, tuition: "$35,000", chance: "78%" },
      { name: "Global University", country: "Netherlands", ranking: 38, tuition: "$25,000", chance: "72%" },
    ],
    medium_chance: [
      { name: "Research University", country: "UK", ranking: 78, tuition: "$55,000", chance: "55%" },
      { name: "Science Academy", country: "Australia", ranking: 92, tuition: "$48,000", chance: "58%" },
    ],
    low_chance: [
      { name: "Elite University", country: "USA", ranking: 12, tuition: "$85,000", chance: "35%" },
      { name: "Oxford-like", country: "UK", ranking: 5, tuition: "$95,000", chance: "28%" },
    ],
    plan: [
      "📚 Начните подготовку к IELTS/TOEFL (целевой балл: 7.0+)",
      "📝 Подготовьте мотивационное письмо (2-3 недели)",
      "📧 Соберите рекомендации от преподавателей",
      "💰 Изучите возможности стипендий и грантов",
      "🎯 Подайте заявления в университеты (за 3-6 месяцев до дедлайна)",
      "💼 Подготовьтесь к собеседованиям",
    ],
    recommendations: [
      "✅ Ваш GPA отличный! Сосредоточьтесь на языковой подготовке",
      "💡 Участвуйте в волонтёрстве и проектах для укрепления профиля",
      "💰 Изучите возможности стипендий в выбранных университетах",
      "📅 Начните подготовку минимум за 6 месяцев до дедлайна",
    ],
  }

  displayResults(demoResults)
}

function displayUniversitiesByCategory(elementId, universities) {
  const container = document.getElementById(elementId)

  if (universities.length === 0) {
    container.innerHTML = '<p class="no-results">Нет университетов в этой категории</p>'
    return
  }

  container.innerHTML = universities
    .map(
      (uni) => `
        <div class="university-card">
            <div class="university-header">
                <h4 class="university-name">${uni.name}</h4>
                ${uni.chance ? `<span class="chance-badge">${uni.chance}</span>` : ""}
            </div>
            <div class="university-details">
                <p><span class="detail-icon">📍</span> ${uni.country}</p>
                <p><span class="detail-icon">🏆</span> Рейтинг QS: <strong>#${uni.ranking}</strong></p>
                <p><span class="detail-icon">💰</span> Стоимость: <strong>${uni.tuition}/год</strong></p>
            </div>
        </div>
    `,
    )
    .join("")
}

function resetForm() {
  document.getElementById("aiForm").reset()
  document.getElementById("resultsSection").style.display = "none"
  document.getElementById("resultsContent").style.display = "none"
  window.scrollTo({ top: 0, behavior: "smooth" })
}

function loadSavedFormData() {
  if (typeof window.Auth === "undefined") {
    setTimeout(loadSavedFormData, 100)
    return
  }

  const Auth = window.Auth
  if (!Auth) return

  const currentUser = Auth.getCurrentUser()
  if (!currentUser) return

  const Database = window.Database
  if (!Database) return

  const history = Database.getHistory(currentUser.email)
  if (!history || history.length === 0) return

  // Get the most recent search
  const lastSearch = history[history.length - 1]

  // Show a notice that we can load previous data
  const formSection = document.querySelector(".form-section")
  if (!formSection) return

  if (document.querySelector(".history-notice")) return

  const notice = document.createElement("div")
  notice.className = "history-notice"
  notice.innerHTML = `
    <div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #3b82f6;">
      <p style="margin: 0 0 10px 0; font-weight: 500;">Найдены сохраненные данные</p>
      <p style="margin: 0 0 10px 0; font-size: 14px; color: #666;">
        Последний поиск: ${new Date(lastSearch.timestamp).toLocaleDateString("ru-RU")}
      </p>
      <button type="button" class="btn btn-secondary btn-small" onclick="fillFormFromHistory()">Заполнить форму</button>
      <button type="button" class="btn btn-secondary btn-small" onclick="clearHistoryNotice()">Заполнить заново</button>
    </div>
  `
  formSection.insertBefore(notice, formSection.firstChild)
}

window.fillFormFromHistory = () => {
  const Auth = window.Auth
  const currentUser = Auth.getCurrentUser()
  const Database = window.Database
  const history = Database.getHistory(currentUser.email)
  const lastSearch = history[history.length - 1]

  // Fill form fields
  document.getElementById("country").value = lastSearch.country || ""
  document.getElementById("gpa").value = lastSearch.gpa || ""
  document.getElementById("budget").value = lastSearch.budget || ""
  document.getElementById("major").value = lastSearch.major || ""
  document.getElementById("english").value = lastSearch.english || ""
  document.getElementById("achievements").value = lastSearch.achievements || ""
  document.getElementById("deadline").value = lastSearch.deadline || ""
  document.getElementById("goals").value = lastSearch.goals || ""

  // Fill exams
  if (lastSearch.exams && lastSearch.exams.length > 0) {
    // Clear existing exam inputs
    document.getElementById("examsContainer").innerHTML = ""
    examCounter = 0

    // Add saved exams
    lastSearch.exams.forEach((exam) => {
      addExamInput()
      const lastExamId = examCounter
      document.querySelector(`select[name="exam_type_${lastExamId}"]`).value = exam.type
      showScoreInput(lastExamId)
      document.querySelector(`input[name="exam_score_${lastExamId}"]`).value = exam.score
    })
  }

  clearHistoryNotice()
}

function clearHistoryNotice() {
  const notice = document.querySelector(".history-notice")
  if (notice) {
    notice.remove()
  }
}

const continentCountries = {
  "north-america": [
    { value: "usa", name: "США" },
    { value: "canada", name: "Канада" },
    { value: "mexico", name: "Мексика" },
  ],
  europe: [
    { value: "uk", name: "Великобритания" },
    { value: "germany", name: "Германия" },
    { value: "france", name: "Франция" },
    { value: "netherlands", name: "Нидерланды" },
    { value: "spain", name: "Испания" },
    { value: "italy", name: "Италия" },
    { value: "switzerland", name: "Швейцария" },
    { value: "austria", name: "Австрия" },
    { value: "belgium", name: "Бельгия" },
    { value: "sweden", name: "Швеция" },
    { value: "norway", name: "Норвегия" },
    { value: "denmark", name: "Дания" },
    { value: "finland", name: "Финляндия" },
    { value: "poland", name: "Польша" },
    { value: "czech", name: "Чехия" },
  ],
  asia: [
    { value: "china", name: "Китай" },
    { value: "japan", name: "Япония" },
    { value: "south-korea", name: "Южная Корея" },
    { value: "singapore", name: "Сингапур" },
    { value: "malaysia", name: "Малайзия" },
    { value: "thailand", name: "Таиланд" },
    { value: "uae", name: "ОАЭ" },
    { value: "turkey", name: "Турция" },
    { value: "india", name: "Индия" },
  ],
  oceania: [
    { value: "australia", name: "Австралия" },
    { value: "new-zealand", name: "Новая Зеландия" },
  ],
  "south-america": [
    { value: "brazil", name: "Бразилия" },
    { value: "argentina", name: "Аргентина" },
    { value: "chile", name: "Чили" },
  ],
  africa: [
    { value: "south-africa", name: "ЮАР" },
    { value: "egypt", name: "Египет" },
  ],
}

window.updateCountryOptions = () => {
  const continentSelect = document.getElementById("continent")
  const countrySelect = document.getElementById("country")

  const selectedContinent = continentSelect.value

  if (!selectedContinent) {
    countrySelect.disabled = true
    countrySelect.innerHTML = '<option value="">Сначала выбери континент</option>'
    return
  }

  countrySelect.disabled = false
  countrySelect.innerHTML = '<option value="">Выбери страну</option>'

  const countries = continentCountries[selectedContinent] || []
  countries.forEach((country) => {
    const option = document.createElement("option")
    option.value = country.value
    option.textContent = country.name
    countrySelect.appendChild(option)
  })
}

// Temporary function to start discussion without authentication
function saveResultsAndStartDiscussionTemp() {
  // Save results temporarily
  const formData = new FormData(document.getElementById("aiForm"))
  const userData = Object.fromEntries(formData)

  const exams = []
  for (let i = 1; i <= examCounter; i++) {
    const examType = formData.get(`exam_type_${i}`)
    const examScore = formData.get(`exam_score_${i}`)
    if (examType && examScore) {
      exams.push({ type: examType, score: examScore })
    }
  }
  userData.exams = exams

  // Get current results
  const results = window.Storage.get("aiResults")

  // Create temporary discussion
  const discussion = {
    id: "temp_" + Date.now().toString(),
    title: `Обсуждение: ${userData.country} - ${userData.major}`,
    functionType: "university-selection",
    formData: userData,
    results: results,
    messages: [
      {
        sender: "ai",
        text: `Привет! Я проанализировал твои данные и подобрал ${(results?.high_chance?.length || 0) + (results?.medium_chance?.length || 0) + (results?.low_chance?.length || 0)} университетов. Какие вопросы у тебя есть?`,
        timestamp: new Date().toISOString(),
      },
    ],
    createdAt: new Date().toISOString(),
    isTemporary: true,
  }

  // Save temporarily without auth
  window.Storage.save("tempDiscussion", discussion)
  window.Storage.save("activeDiscussionId", discussion.id)

  // Redirect to chat
  console.log("[v0] Redirecting to chat with temp discussion ID:", discussion.id)
  window.location.href = "chat.html"
}

window.saveResultsAndStartDiscussionTemp = saveResultsAndStartDiscussionTemp

function saveResultsAndStartDiscussion() {
  const Auth = window.Auth
  const Database = window.Database

  if (!Auth || !Database) {
    console.error("[v0] Auth or Database not available")
    saveResultsAndStartDiscussionTemp()
    return
  }

  const currentUser = Auth.getCurrentUser()

  if (!currentUser) {
    const shouldContinue = confirm(
      "Хотите продолжить без регистрации?\n\nНажмите OK для продолжения без регистрации\nНажмите Отмена для входа в аккаунт",
    )
    if (shouldContinue) {
      saveResultsAndStartDiscussionTemp()
    } else {
      window.location.href = "login.html"
    }
    return
  }

  // Save search to history
  const formData = new FormData(document.getElementById("aiForm"))
  const userData = Object.fromEntries(formData)

  const exams = []
  for (let i = 1; i <= examCounter; i++) {
    const examType = formData.get(`exam_type_${i}`)
    const examScore = formData.get(`exam_score_${i}`)
    if (examType && examScore) {
      exams.push({ type: examType, score: examScore })
    }
  }
  userData.exams = exams

  Database.saveToHistory(currentUser.email, userData)

  // Get current results
  const results = window.Storage.get("aiResults")

  // Create and save discussion with results
  const discussion = {
    id: Date.now().toString(),
    title: `Обсуждение: ${userData.country} - ${userData.major}`,
    functionType: "university-selection",
    formData: userData,
    results: results,
    messages: [
      {
        sender: "ai",
        text: `Привет! Я проанализировал твои данные и подобрал ${(results?.high_chance?.length || 0) + (results?.medium_chance?.length || 0) + (results?.low_chance?.length || 0)} университетов. Какие вопросы у тебя есть?`,
        timestamp: new Date().toISOString(),
      },
    ],
    createdAt: new Date().toISOString(),
  }

  console.log("[v0] Saving discussion:", discussion)
  Database.saveDiscussion(currentUser.email, discussion)

  // Save plan to calendar
  if (results?.plan) {
    results.plan.forEach((step, index) => {
      const eventDate = new Date()
      eventDate.setDate(eventDate.getDate() + index * 7)

      Database.saveCalendarEvent(currentUser.email, {
        title: `Шаг ${index + 1}: ${step.substring(0, 50)}`,
        description: step,
        date: eventDate.toISOString().split("T")[0],
        type: "plan",
      })
    })
  }

  // Save the discussion ID for chat to load
  window.Storage.save("activeDiscussionId", discussion.id)

  // Redirect to chat
  console.log("[v0] Redirecting to chat with discussion ID:", discussion.id)
  window.location.href = "chat.html"
}
